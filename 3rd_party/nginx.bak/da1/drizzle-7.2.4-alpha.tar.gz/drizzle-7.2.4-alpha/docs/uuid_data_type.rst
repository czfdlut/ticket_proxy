UUID Data Type
==============

'TODO'

Drizzle uses libuuid to generate UUID values.

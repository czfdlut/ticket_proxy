Deleting Data
=============

'TODO'
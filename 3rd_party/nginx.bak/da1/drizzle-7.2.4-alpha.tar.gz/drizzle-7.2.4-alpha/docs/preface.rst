================
Preface
================

Welcome to Drizzle's official documentation. This community-generated resource covers what Drizzle is, the SQL language as implemented by Drizzle, and other basic and advanced topics. It has been written by the Drizzle developers and other volunteers in parallel to the development of the Drizzle software. It describes all the functionality that the current version of Drizzle officially supports.

There are other sites and locations for information on Drizzle and contributing to the project. You can find code, bug reports, and downloads at `Launchpad <https://launchpad.net/drizzle>`_. The wiki for Drizzle can be found at http://wiki.drizzle.org/Main_Page.

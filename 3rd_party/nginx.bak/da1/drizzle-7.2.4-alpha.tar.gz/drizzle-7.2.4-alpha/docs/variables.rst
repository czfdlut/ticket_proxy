
.. _user_defined_variables:

User Defined Variables
======================

Users can create local variables with the following syntax.

.. code-block:: mysql

   SET @variable = "some string";

Variables are session level only. They can be used in queries. The can be set
from queries.

ORDER BY
========

'TODO'

SQL ORDER BY Syntax:

.. code-block:: mysql

	SELECT column_name(s)
	FROM table_name
	ORDER BY column_name(s) ASC|DESC;

'TODO'
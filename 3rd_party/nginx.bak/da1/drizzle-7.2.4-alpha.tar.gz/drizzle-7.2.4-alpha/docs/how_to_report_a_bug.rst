How to Report a Bug
===================

Drizzle bugs can be reported at https://bugs.launchpad.net/drizzle. On the right side of the page you will see the link to "Report a bug", alongside links to ask questions, submit code, etc. 

If you're interested in helping to fix some of Drizzle's current bugs, the team  maintains a list of low hanging fruit bugs on Launchpad: https://bugs.edge.launchpad.net/drizzle/+bugs?field.tag=low-hanging-fruit

.. seealso:: :ref:`contributing_code`

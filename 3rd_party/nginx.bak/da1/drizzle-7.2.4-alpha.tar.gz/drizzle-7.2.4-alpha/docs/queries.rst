Executing Queries
=================

'TODO'

.. code-block:: mysql

	SELECT * FROM table_name;

'TODO' 

Keywords and clauses include:

.. toctree::
   :maxdepth: 2

   where
   distinct
   groupby
   having
   orderby
   join

For example:

.. code-block:: mysql

	SELECT first_column_name, second_column_name
	FROM table_name
	WHERE first_column_name > 1000;

'TODO'
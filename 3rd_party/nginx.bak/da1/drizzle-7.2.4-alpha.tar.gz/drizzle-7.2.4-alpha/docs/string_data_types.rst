String Data Types
=================


VARCHAR and VARBINARY
---------------------

'TODO'

.. note::

   ``CHAR`` and ``BINARY`` types are implicitly changed to ``VARCHAR`` and
   ``VARBINARY`` respectively.

TEXT and BLOB
-------------

'TODO'

ENUM
----

'TODO'


UTF-8
------

'TODO'
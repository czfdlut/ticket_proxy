Data Types
==========

Drizzle data types can be grouped into the following categories:

.. toctree:: 
   :maxdepth: 2

   numeric_data_types
   date_time_data_types
   string_data_types
   boolean_data_type
   uuid_data_type

Data Definition Language
=========================

'TODO'

.. toctree::
   :maxdepth: 2

   tables
   schemas
   indexes

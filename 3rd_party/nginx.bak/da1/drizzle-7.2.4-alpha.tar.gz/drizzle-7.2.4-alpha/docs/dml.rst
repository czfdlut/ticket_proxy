Data Manipulation Language
==========================

'TODO'

.. toctree::
   :maxdepth: 2

   delete
   insert
   replace
   update
   load_data_infile

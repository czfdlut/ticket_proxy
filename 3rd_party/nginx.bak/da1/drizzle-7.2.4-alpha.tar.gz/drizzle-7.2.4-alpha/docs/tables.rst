Tables
======

'TODO'

.. toctree:: 
	:maxdepth: 2

	alter_table
	create_table
	drop_table
	truncate
	rename

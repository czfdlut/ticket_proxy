.. _rand_function_plugin:

RAND Function
=============

The ``rand_function`` plugin provides these :doc:`/functions/overview`:

* :ref:`rand-function`

.. _rand_function_loading:

Loading
-------

This plugin is loaded by default.  To stop the plugin from loading by
default, start :program:`drizzled` with::

   --plugin-remove=rand_function

.. seealso:: :ref:`drizzled_plugin_options` for more information about adding and removing plugins.

.. _rand_function_authors:

Authors
-------

Unknown

.. _rand_function_version:

Version
-------

Unknown

.. _zeromq_plugin:

ZeroMQ
======

See :ref:`zeromq_applier`.

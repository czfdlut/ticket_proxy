.. _rabbitmq_plugin:

RabbitMQ Integration
====================

See :ref:`rabbitmq_applier`.

Replication Slave
==================

See :ref:`slave_applier`.

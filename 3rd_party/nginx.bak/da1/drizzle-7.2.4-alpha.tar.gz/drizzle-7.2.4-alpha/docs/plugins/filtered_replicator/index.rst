Filtered Replicator
===================

See :ref:`filtered_replicator`.

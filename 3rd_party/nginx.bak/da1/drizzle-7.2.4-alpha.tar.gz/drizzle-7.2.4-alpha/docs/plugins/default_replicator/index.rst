Default Replicator
==================

See :ref:`default_replicator`.

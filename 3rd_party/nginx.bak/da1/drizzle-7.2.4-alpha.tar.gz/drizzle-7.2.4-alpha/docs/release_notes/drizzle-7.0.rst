Drizzle 7.0
===========

:Released: 2011-03-15
:Version: 2011.03.13
:URL: http://blog.drizzle.org/2011/03/15/drizzle-2011-03-12-ga-tarball-has-been-released/


Comparative Functions
=====================

'TODO'

.. _like-function:

LIKE            
----




.. _regex-function:

REGEX
-----


.. _regexp-function:

REGEXP
------



.. _strcmp-function:

STRCMP
------


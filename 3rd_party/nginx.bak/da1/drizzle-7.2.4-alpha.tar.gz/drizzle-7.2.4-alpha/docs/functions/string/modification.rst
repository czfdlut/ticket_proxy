String Modification Functions
=============================

'TODO'
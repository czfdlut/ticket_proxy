Position Functions
==================


'TODO'
Conversion Functions
====================

'TODO'

.. _ascii-function:

ASCII
-----


.. _bin-function:

BIN
---

.. _char-function:

CHAR
----


.. _hex-function:

HEX
---


.. _unhex-function:

UNHEX
-----



.. _lower-function:

LOWER
-----


.. _lcase-function:

LCASE
-----


.. _ucase-function:

UCASE
-----


.. _upper-function:

UPPER
-----



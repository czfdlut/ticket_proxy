Other String Functions
======================

'TODO'

.. _coercibility-function:

COERCIBILITY
------------



.. _elt-function:

ELT
---


.. _export-set-function:

EXPORT_SET
----------


.. _format-function:

FORMAT
------


.. _load-file-function:

LOAD_FILE
---------


.. _lpad-function:

LPAD
----


.. _make-set-function:

MAKE_SET
--------



.. _match-function:

MATCH
-----


.. _mid-function:

MID
---


.. _quote-function:

QUOTE
-----


.. _repeat-function:

REPEAT
------


.. _replace-function:

REPLACE
-------



.. _reverse-function:

REVERSE
-------




.. _right-function:

RIGHT
-----



.. _rpad-function:

RPAD
----




.. _soundex-function:

SOUNDEX
-------




.. _substr-function:

SUBSTR
------



.. _substring-function:

SUBSTRING
---------


.. _substring-index-function:


SUBSTRING_INDEX
---------------



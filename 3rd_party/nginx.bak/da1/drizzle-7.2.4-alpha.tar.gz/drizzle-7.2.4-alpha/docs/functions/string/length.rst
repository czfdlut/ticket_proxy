Length and Size Functions
=========================

'TODO'

.. _char-length-function:

CHAR_LENGTH
-----------


.. _character-length-function:

CHARACTER_LENGTH
----------------


.. _length-function:

LENGTH
------


.. _octet-length-function:

OCTET_LENGTH
-------------


Logical and Comparison Operators
================================

==============================     ================================
Operators                           Description
==============================     ================================
:ref:`and` &&                       Logical AND
:ref:`or` (||)                      Logical OR
:ref:`xor` 	                    Logical XOR
:ref:`not` (!)                      Logical NOT
:ref:`less_than` <      	    less than
:ref:`greater_than` >   	    greater than
:ref:`less_or_equal` <=             less than or equal to
:ref:`greater_or_equal` >=          greater than or equal to
:ref:`equal` =  	            equal
:ref:`not_equal` <> or !=           not equal
==============================     ================================


'TODO'

.. _and:

AND
---

.. _or:

OR
--

.. _xor:

XOR
---

.. _not:

NOT
---



.. _less_than:

LESS THAN
----------



.. _greater_than:

GREATER THAN
-------------


.. _less_or_equal:

LESS THAN OR EQUAL
-------------------


.. _greater_or_equal:

GREATER THAN OR EQUAL
----------------------

.. _equal:

EQUAL
-----


.. _not_equal:

NOT EQUAL
----------


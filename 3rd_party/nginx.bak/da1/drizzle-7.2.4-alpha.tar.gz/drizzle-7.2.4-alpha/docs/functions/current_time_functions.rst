CURRENT TIME FUNCTIONS
=======================

'TODO'
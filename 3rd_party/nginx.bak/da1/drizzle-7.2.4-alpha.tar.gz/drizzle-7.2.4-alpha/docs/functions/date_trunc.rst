DATE TRUNC
===========

'TODO'
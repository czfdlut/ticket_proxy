EXTRACT DATE FUNCTION
======================

Syntax
------

.. code-block:: mysql

	EXTRACT(field FROM source)

'TODO'
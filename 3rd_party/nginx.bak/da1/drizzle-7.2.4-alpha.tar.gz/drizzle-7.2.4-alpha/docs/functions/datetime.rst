Date and Time Functions
=======================

.. toctree::
   :hidden: 
   
   current_time_functions
   extract_date_functions
   date_trunc

Current
-------

For examples of the following, see :doc:`current_time_functions`.

'TODO'

Drizzle timezone is always UTC.

Extract
-------

For examples of the following, see :doc:`extract_date_functions`.

'TODO'


DATE TRUNC
----------

For an example of the following, see :doc:`date_trunc`.

'TODO'
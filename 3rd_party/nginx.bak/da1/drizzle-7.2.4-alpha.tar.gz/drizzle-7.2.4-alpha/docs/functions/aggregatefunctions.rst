Aggregate Functions
===================

'TODO'

The following are examples of aggregate functions:

:ref:`avg`:  'TODO'

:ref:`count`
(DISTINCT):  'TODO'

:ref:`count`:  'TODO'
	
:ref:`group_concat`:  'TODO'

:ref:`max`:  'TODO'


.. _avg:

AVG
---

'TODO'

.. _count:

COUNT
-----

'TODO'

.. _group_concat:

GROUP CONCAT
-------------

'TODO'

.. _max:

MAX and MIN
------------

'TODO'
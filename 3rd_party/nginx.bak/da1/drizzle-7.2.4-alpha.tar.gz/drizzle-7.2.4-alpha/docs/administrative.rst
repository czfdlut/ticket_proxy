Administrative Commands
=======================

.. toctree::
   :maxdepth: 2

   kill
   flush
   unlock
   analyze 
   check

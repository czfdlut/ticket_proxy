DROP INDEX
============

'TODO'

Drizzle does not currently support fast drop index.

RENAME
======

'TODO'

.. code-block:: mysql

	CREATE TABLE new_name (...);
	RENAME TABLE old_name TO backup_table, new_name TO old_name;

'TODO'

.. seealso:: :doc:`/alter_table`

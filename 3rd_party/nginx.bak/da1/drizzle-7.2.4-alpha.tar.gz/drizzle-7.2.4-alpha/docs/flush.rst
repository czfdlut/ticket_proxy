FLUSH
=====

'TODO'

.. code-block:: mysql

   FLUSH flush_option [, flush_option] ...

flush_option
------------

* TABLES table_name [, table_name]
	
'TODO'

* TABLES WITH READ LOCK
	
'TODO'

* LOGS
	
'TODO'

* STATUS
	
'TODO'
    
'TODO' (how to release a lock)

UNLOCK TABLES
=============

UNLOCK TABLES is used after a call to FLUSH TABLES WITH READ LOCK to release
the read lock that has been placed on tables.

DESCRIBE
========

DESCRIBE is an Oracle compatible command that can be used to gain the definition of a TABLE.

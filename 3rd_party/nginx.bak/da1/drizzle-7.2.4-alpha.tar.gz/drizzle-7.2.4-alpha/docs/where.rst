WHERE
=====

'TODO'

.. code-block:: mysql

	SELECT column_name(s)
	FROM table_name
	WHERE column_name operator value
	
'TODO' (examples)
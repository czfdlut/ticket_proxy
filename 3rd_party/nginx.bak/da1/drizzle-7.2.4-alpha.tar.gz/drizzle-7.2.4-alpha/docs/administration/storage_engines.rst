Storage Engines
===============

Drizzle uses the :ref:`innobase_plugin` for all tables.  The
:ref:`myisam_plugin` and :ref:`memory_plugin` are only used
for internal or temporary tables.

DISTINCT
========

'TODO'

SQL SELECT DISTINCT Syntax: 

.. code-block:: mysql

	SELECT DISTINCT column_name(s)
	FROM table_name

'TODO'
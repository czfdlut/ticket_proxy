ALTER TABLE
===========

'TODO'
CREATE INDEX
============

.. code-block:: mysql

   CREATE [UNIQUE] INDEX index_name [USING {BTREE | HASH}] ON table_name (column_name [length] [ASC | DESC], ...);

'TODO'
More Ways to Contribute
=======================

Write Translations
------------------

Drizzle is multilingual and Launchpad provides an easy interface
to help translate Drizzle into other languages:
https://translations.launchpad.net/drizzle

Advocate Drizzle
----------------

Please join the `Drizzle Advocacy mailing list <https://launchpad.net/~drizzle-advocacy>`_ and help promote and expand knowledge about Drizzle.

Make a Donation
---------------

Drizzle is an Associated Project at the
`Software in the Public Interest (SPI) <http://spi-inc.org/>`_.  You can `make
a financial donation to Drizzle <http://www.drizzle.org/content/donations>`_
through the SPI.

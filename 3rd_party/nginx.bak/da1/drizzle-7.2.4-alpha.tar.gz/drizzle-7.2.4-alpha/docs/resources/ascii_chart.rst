ASCII Conversion Chart
=======================

'TODO'	 

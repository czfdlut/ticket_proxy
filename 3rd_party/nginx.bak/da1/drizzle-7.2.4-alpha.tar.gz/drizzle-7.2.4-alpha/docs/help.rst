.. _help:

Help and Support
================

If you have any questions, the core developers and many community members
are frequently avaiable on the
`#drizzle <irc://irc.freenode.net/drizzle>`_
`Freenode <http://freenode.net/>`_ IRC channel or on the
`Drizzle Discuss <https://launchpad.net/~drizzle-discuss>`_ mailing list.

A number of companies provide `commercial support <http://www.drizzle.org/content/support-and-services>`_ for Drizzle.

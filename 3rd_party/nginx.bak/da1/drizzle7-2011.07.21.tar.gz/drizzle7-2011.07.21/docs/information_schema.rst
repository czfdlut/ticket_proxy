INFORMATION_SCHEMA
==================

The INFORMATION_SCHEMA contains only tables and columns defined by the ANSI
SQL standard. It should be used over DATA_DICTIONARY if you wish to write
tools portable to other RDBMs.



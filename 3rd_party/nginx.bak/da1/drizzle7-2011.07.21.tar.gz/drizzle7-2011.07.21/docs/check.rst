CHECK
=====

CHECK TABLE table_name

CHECK TABLE checks a table or tables for errors.

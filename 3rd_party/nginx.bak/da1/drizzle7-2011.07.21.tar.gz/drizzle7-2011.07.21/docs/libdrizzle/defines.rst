.. highlightlang:: c

Defines
-------


.. c:macro:: drizzle_get_byte2

.. c:macro:: drizzle_get_byte3

.. c:macro:: drizzle_get_byte4

.. c:macro:: drizzle_get_byte8

.. c:macro:: drizzle_set_byte2

.. c:macro:: drizzle_set_byte3

.. c:macro:: drizzle_set_byte4

.. c:macro:: drizzle_set_byte8

.. c:macro:: drizzle_mb_char

.. c:macro:: drizzle_mb_length

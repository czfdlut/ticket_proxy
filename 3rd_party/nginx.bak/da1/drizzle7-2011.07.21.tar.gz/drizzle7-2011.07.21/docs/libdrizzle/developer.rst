libdrizzle Developer Reference Manual
=====================================

:Release: |version|
:Date: |today|

This manual documents the internals of libdrizzle.


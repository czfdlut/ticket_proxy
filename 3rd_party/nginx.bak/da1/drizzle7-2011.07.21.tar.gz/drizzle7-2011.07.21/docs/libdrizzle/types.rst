.. highlightlang:: c

Types
-----


.. c:type:: drizzle_st

.. c:type:: drizzle_con_tcp_st

.. c:type:: drizzle_con_uds_st

.. c:type:: drizzle_con_st

.. c:type:: drizzle_query_st

.. c:type:: drizzle_result_st

.. c:type:: drizzle_column_st

.. c:type:: drizzle_field_t

.. c:type:: drizzle_row_t

.. c:type:: drizzle_charset_t

.. c:type:: drizzle_context_free_fn

.. c:type:: drizzle_log_fn

.. c:type:: drizzle_state_fn

.. c:type:: drizzle_con_context_free_fn

.. c:type:: drizzle_query_context_free_fn

.. c:type:: drizzle_event_watch_fn


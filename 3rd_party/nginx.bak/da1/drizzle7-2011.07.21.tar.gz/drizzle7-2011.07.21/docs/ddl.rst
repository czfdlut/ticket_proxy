Data Description Language
=========================

The Data Definition Language (DDL) is used to define data and their relationships to other data. It is primarily used to create and destroy databases and database objects.

.. toctree::
   :maxdepth: 2

   tables
   schemas
   indexes

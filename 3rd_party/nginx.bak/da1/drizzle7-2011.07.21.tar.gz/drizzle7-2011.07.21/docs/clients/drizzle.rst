Drizzle Commandline Client
==========================

The :program:`drizzle` command line client is the primary program for ad-hoc
connecting to and manipulating a Drizzle database.

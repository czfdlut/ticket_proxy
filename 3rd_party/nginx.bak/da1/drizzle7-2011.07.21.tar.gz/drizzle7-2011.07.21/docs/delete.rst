Deleting Data
=============

In Drizzle you can make use of DELETE in order to delete a single record (or multiple records) of data from a table.

A typical query might be:

.. code-block:: mysql

	DELETE FROM table_1;

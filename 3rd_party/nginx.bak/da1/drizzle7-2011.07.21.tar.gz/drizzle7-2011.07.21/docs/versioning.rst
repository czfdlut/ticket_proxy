Releases and Versioning
========================

A new version of Drizzle is released every two weeks. The release is labelled "YEAR-MONTH-REVISION#"

This shouldn't be confused with "YEAR-MONTH-DAY". For example, in "2011-02-10" the "10" refers to the revision number and not the date.

You can always see the latest release on Launchpad. 
Logging
=======

Drizzle provides a number of logging plugins.

.. toctree::
   :maxdepth: 2

   syslog
   file

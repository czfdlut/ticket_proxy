Documentation Licensing
=======================

Docs Content
------------

.. image:: cc-symbol.png
   :alt:  Creative Commons License
   :target:  http://creativecommons.org/licenses/by-sa/3.0/

Drizzle Documentation (docs.drizzle.org) is licensed under a `Creative Commons Share Alike 3.0 license <http://creativecommons.org/licenses/by-sa/3.0>`_.

About the Drizzle logo
----------------------

The Drizzle logo was created by Zak Greant under the `Creative Commons Share Alike 3.0 license <http://creativecommons.org/licenses/by-sa/3.0>`_.

The logo is available in SVG format on `Wikipedia <http://en.wikipedia.org/wiki/File:Drizzle-logotype.svg>`_.
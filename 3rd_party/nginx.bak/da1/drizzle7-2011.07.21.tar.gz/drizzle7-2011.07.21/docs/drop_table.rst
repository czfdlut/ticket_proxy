DROP TABLE
===========

DROP TABLE removes a table from a schema once all queries or DML have ceased on the given table.

.. code-block:: mysql 

	DROP TABLE [ IF EXISTS ] table_name

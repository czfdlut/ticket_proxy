DROP INDEX
============

This drops a given index on the named table.

.. code-block:: mysql

	DROP INDEX table_1_index ON table_1;

Drizzle does not currently support fast drop index.
